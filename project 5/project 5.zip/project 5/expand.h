//
// Created by Alex Ernst on 2019-04-29.
//

#ifndef PROJECT_5_WRITE_H
#define PROJECT_5_WRITE_H

#include "node.h"
#include <fstream>
#include <string>

void write_preorder(node* tree, std::ofstream &fout);

#endif //PROJECT_5_WRITE_H
