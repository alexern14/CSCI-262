//
// Created by Alex Ernst on 2019-04-29.
//

#ifndef PROJECT_5_PLAY_GAME_H
#define PROJECT_5_PLAY_GAME_H

#include "node.h"

void play_game(node* root);

#endif //PROJECT_5_PLAY_GAME_H
